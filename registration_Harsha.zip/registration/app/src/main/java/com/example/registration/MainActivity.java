package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText, confirmPasswordEditText, emailEditText, phoneEditText;
    private Button signUpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        confirmPasswordEditText = findViewById(R.id.confirm_password);
        emailEditText = findViewById(R.id.mail);
        phoneEditText = findViewById(R.id.phone_no);
        signUpButton = findViewById(R.id.loginButton);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Perform form validation
                if (isValidForm()) {
                    // Form is valid, proceed with sign-up logic
                    performSignUp();
                } else {
                    // Form is not valid, show an error message
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidForm() {
        // Basic form validation logic
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String confirmPassword = confirmPasswordEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();

        if (!password.equals(confirmPassword)) {
            Toast.makeText(MainActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!phone.matches("\\d{10}")) {
            Toast.makeText(MainActivity.this, "Enter a valid 10-digit phone number", Toast.LENGTH_SHORT).show();
            return false;
        }

        return !username.isEmpty() && !password.isEmpty() && !confirmPassword.isEmpty()
                && !email.isEmpty();
    }

    private void performSignUp() {
        Toast.makeText(this, "Sign-up successful!", Toast.LENGTH_SHORT).show();
    }
}

