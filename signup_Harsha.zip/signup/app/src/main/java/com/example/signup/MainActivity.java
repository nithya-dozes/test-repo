package com.example.signup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username, password, confirm_password, mail, phone_no;
    Button loginButton,login;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        confirm_password = (EditText) findViewById(R.id.confirm_password);
        mail = (EditText) findViewById(R.id.mail);
        phone_no = (EditText) findViewById(R.id.phone_no);
        loginButton = (Button) findViewById(R.id.loginButton);
        login = (Button) findViewById(R.id.login);
        DB = new DBHelper(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String confirmPassword = confirm_password.getText().toString();
                String mail1 = mail.getText().toString();
                String phone = phone_no.getText().toString();

                if (user.equals("")||pass.equals("")||confirmPassword.equals(""))
                    Toast.makeText(MainActivity.this,"Please fill all the fields",Toast.LENGTH_SHORT).show();
                else{
                    if (pass.equals(confirmPassword)){
                        Boolean checkuser = DB.checkusername(user);
                        if(checkuser == false){
                            Boolean insert = DB.insertData(user,pass,mail1,phone,confirmPassword);
                            if(insert == true){
                                Toast.makeText(MainActivity.this,"Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), HomeActivity2.class);
                                startActivity(intent);

                            }
                            else{
                                Toast.makeText(MainActivity.this,"Registration failed",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(MainActivity.this,"user already exists, please sign in",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(MainActivity.this,"Passwords do not match",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        }
        );
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity2.class);

            }
        });
    }
}