package com.example.example;
import android.content.ContentValues;
import android.content.Context;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DHelper extends SQLiteOpenHelper{
    private static final String dbname="ngo_management_system";

    public DHelper(Context context)
    {
        super(context,dbname,null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase sql_database)
    {
        String qry = "create table events(event_name TEXT, event_id INTEGER primary key autoincrement, event_description TEXT,date TEXT, venue TEXT,time TEXT)";
        sql_database.execSQL(qry);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sq, int i, int j)
    {
        sq.execSQL("drop table if exists events");
        onCreate(sq);
    }
    public boolean insertion_data(String event_name, String event_description, String date, String venue, String time)
    {
        SQLiteDatabase my_db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("event_name",event_name);
        values.put("event_description",event_description);
        values.put("date",date);
        values.put("venue",venue);
        values.put("time",time);
        long res = my_db.insert("events",null,values);
        if(res == -1)//says if the insertion operation is happening or not
            return false;
        else
        {
            my_db.close();
            return true;}

    }

}
