package com.example.example;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.Nullable;

public class MainActivity extends AppCompatActivity {
    private EditText text1,text2,text3,text4,text5;
    private Button b_add_event, b_cancel;
    boolean all_checked = false;
    DHelper helper;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text1 =  findViewById(R.id.editTextText);
        text2 =  findViewById(R.id.editTextTextMultiLine);
        text3 =  findViewById(R.id.editTextDate);
        text4 =  findViewById(R.id.editTextTextPostalAddress);
        text5 =  findViewById(R.id.editTextTime);
        b_add_event = findViewById(R.id.button_add);
        b_cancel = findViewById(R.id.button_cancel);

        b_add_event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                all_checked = check_fields();

                helper = new DHelper(getApplicationContext());//calls constructor to initialize the context with this main_Activity file

                if (all_checked) {//checks if all the constraints have been checked
                    Toast.makeText(MainActivity.this,"Event successfully added",Toast.LENGTH_LONG).show();
                    boolean successful_reg = helper.insertion_data(text1.getText().toString(),text2.getText().toString(),text3.getText().toString(),text4.getText().toString(),text5.getText().toString());

                   if(successful_reg) {
                        Toast.makeText(MainActivity.this,"Event successfully added",Toast.LENGTH_LONG).show();

                        Intent i = new Intent(getApplicationContext(), Activity_list_of_events.class);
                        startActivity(i);
                    }
                }
            }
        });
        b_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                MainActivity.this.finish();
            }
        });


    }
    private boolean check_fields() {
        if((text1.getText().toString()).equals(""))
        {
            text1.setError("This is a required field");
            return false;
        }
        if((text2.getText().toString()).equals(""))
        {
            text2.setError("This is a required field");
            return false;
        }
        if((text3.getText().toString()).equals(""))
        {
            text3.setError("This is a required field");
            return false;
        }

        if((text4.getText().toString()).equals(""))
        {
            text4.setError("This is a required field");
            return false;
        }
        if((text5.getText().toString()).equals(""))
        {
            text5.setError("This is a required field");
            return false;
        }
        return true;
    }
}
